from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import mysql.connector

app = FastAPI()

# --- Database Configuration ---
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "yourpassword",  # <-- Change this!
    "database": "contact_book"
}

def get_db():
    return mysql.connector.connect(**db_config)

# --- Pydantic Model ---
class Item(BaseModel):
    id: int
    name: str
    price: float

# --- Create ---
@app.post("/items/", response_model=Item)
def create_item(item: Item):
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute(
            "INSERT INTO contacts (id, name, phone, email) VALUES (%s, %s, %s, %s)",
            (item.id, item.name, str(item.price), f"{item.name.lower()}@example.com")  # mocked phone/email
        )
        db.commit()
        return item
    except mysql.connector.Error as e:
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        cursor.close()
        db.close()

# --- Read All ---
@app.get("/items/", response_model=List[Item])
def get_items():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name, phone FROM contacts")
    rows = cursor.fetchall()
    cursor.close()
    db.close()
    return [Item(id=row[0], name=row[1], price=float(row[2])) for row in rows]

# --- Read One ---
@app.get("/items/{item_id}", response_model=Item)
def get_item(item_id: int):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name, phone FROM contacts WHERE id = %s", (item_id,))
    row = cursor.fetchone()
    cursor.close()
    db.close()
    if row:
        return Item(id=row[0], name=row[1], price=float(row[2]))
    raise HTTPException(status_code=404, detail="Item not found")

# --- Update ---
@app.put("/items/{item_id}", response_model=Item)
def update_item(item_id: int, updated_item: Item):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id FROM contacts WHERE id = %s", (item_id,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Item not found")
    cursor.execute(
        "UPDATE contacts SET name = %s, phone = %s WHERE id = %s",
        (updated_item.name, str(updated_item.price), item_id)
    )
    db.commit()
    cursor.close()
    db.close()
    return updated_item

# --- Delete ---
@app.delete("/items/{item_id}", response_model=Item)
def delete_item(item_id: int):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name, phone FROM contacts WHERE id = %s", (item_id,))
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Item not found")
    cursor.execute("DELETE FROM contacts WHERE id = %s", (item_id,))
    db.commit()
    cursor.close()
    db.close()
    return Item(id=row[0], name=row[1], price=float(row[2]))
